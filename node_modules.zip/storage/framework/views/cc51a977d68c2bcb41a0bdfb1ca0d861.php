<?php echo e($userotp); ?>

<?php /**PATH C:\xampp\htdocs\mjcreation\resources\views/mail/otpsendmail.blade.php ENDPATH**/ ?>